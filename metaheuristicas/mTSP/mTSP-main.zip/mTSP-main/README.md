# mTSP
The source code is distributed for academic purposes only.
This page contains the code of the HSNR algorithm presented in the following paper as well as and the instances tested in the paper:

Pengfei He, Jin-Kao Hao. Hybrid search with neighborhood reduction for the multiple traveling salesman problem. Computers & Operations Research January 2022 (105726).

If you meet any problems when you use these materials, please feel free to contact me.
